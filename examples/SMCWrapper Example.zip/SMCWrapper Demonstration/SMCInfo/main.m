//
//  main.m
//  SMCInfo
//
//  Created by Fergus Morrow on 29/09/2014.
//  Copyright (c) 2014 Fergus Morrow. All rights reserved.
//

// #import <Foundation/Foundation.h>
#import "SMCWrapper/SMCWrapper.h"

int main(int argc, const char * argv[]) {
    SMCWrapper *smc = [SMCWrapper sharedWrapper];
    char key[5];
    
    NSNumber *temp;
    if ( [smc readKey:"TC0P" intoNumber:&temp] ){
        NSLog(@"CPU Temperature:\t %@", [temp stringValue]);
    }

    NSNumber *numFans;
    int iNumFans;
    [smc readKey:"FNum" intoNumber:&numFans];
    iNumFans = [numFans intValue];
    
    for (int i=0; i<iNumFans; i++)
    {
        NSLog(@"\n\nFan #%d", i);
        
        NSString *fanID;
        NSNumber *fanRPM,
            *minRPM,
            *maxRPM,
            *safeRPM,
            *tarRPM;
        
        sprintf(key, "F%dID", i);
        if ( [smc readKey:key asString:&fanID] ){
            NSLog(@"Fan ID:\t %@\n", fanID);
        }
        
        sprintf(key, "F%dAc", i); // Actual Speed
        if ( [smc readKey:key intoNumber:&fanRPM] ){
            NSLog(@"Fan Speed (RPM):\t %@\n", fanRPM);
        }
        
        sprintf(key, "F%dMn", i); // Min Speed
        if ( [smc readKey:key intoNumber:&minRPM] ){
            NSLog(@"Min Speed (RPM):\t %@\n", minRPM);
        }
        
        sprintf(key, "F%dMx", i); // Max Speed
        if ( [smc readKey:key intoNumber:&maxRPM] ){
            NSLog(@"Max Speed (RPM):\t %@\n", maxRPM);
        }
        
        sprintf(key, "F%dSf", i); // Safe Speed
        if ( [smc readKey:key intoNumber:&safeRPM] ){
            NSLog(@"Safe Speed (RPM):\t %@\n", safeRPM);
        }
        
        sprintf(key, "F%dTg", i); // Target Speed
        if ( [smc readKey:key intoNumber:&tarRPM] ){
            NSLog(@"Target Speed (RPM):\t %@\n", tarRPM);
        }
    }
    
    return 0;
}
